package com.ldt.musicr.interactors

import com.ldt.musicr.helper.songpreview.PreviewSong

object SongManager {
    var previewingSong: PreviewSong?= null
}