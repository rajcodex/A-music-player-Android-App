package com.ldt.musicr.notification

object PayLoadKey {
    const val CHANGE_PLAYING_STATE = "CHANGE_PLAYING_STATE"
    const val CHANGE_PREVIEW_STATE = "CHANGE_PREVIEW_STATE"
    const val CHANGE_THEME = "CHANGE_THEME"
}